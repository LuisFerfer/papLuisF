<?php include_once("includes/bodybase.inc.php");
top();
?>
    <script>
        var stage=1;
        $('document').ready(function (){
            swapinf(stage);
        });
    </script>


<!-- Banner -->
<section id="bannerinf">


</section>

<!-- One -->
<section id="one" class="wrapper style1 special">
    <div class="container">
        <header class="major">
            <h2>Recordes</h2>
            <p>Aqui poderá ver os seus últimos melhores resultados.</p>
        </header>
        <section>


            <div class="table-wrapper">
                <table>
                    <thead>
                    <tr>

                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>1</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>0</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>0</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>0</td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>0</td>
                    </tr>
                    </tbody>

                </table>
            </div>
            <!-- Two -->
            <section id="two" class="wrapper style2 special">
                <div class="container">
                    <header class="major">
                        <h2>Vermo!</h2>
                        <p>Treine o seu cérebro.</p>
                    </header>

                </div>
            </section>

<?php bottom(); ?>