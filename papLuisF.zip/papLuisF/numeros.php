<?php include_once("includes/bodybase.inc.php");
top();
?>
    <script>
        var nDigitos=1;
        var nEscondido;
        var nCertos=-1;
        var stage=1;
        var tempo = 10;
        $('document').ready(function (){
            swapnum(stage);
        });
    </script>


    <!-- Banner -->
    <section id="bannernum">

    </section>


    <!-- Two -->
    <section id="two" class="wrapper style2 special">
        <div class="container">
            <header class="major">
                <h2>Vermo!</h2>

                <p>Treine o seu cérebro.</p>
            </header>

        </div>
    </section>

<?php bottom(); ?>