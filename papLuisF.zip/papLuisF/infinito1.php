<meta charset="UTF-8">

<h2>Modo Competitivo</h2>
<p>Pode utilizar este modo para bater recordes pessoais ou de amigos.</p>
<p>Junte-se aos melhores na tabela de recordes!</p>
<p>Treine o seu cérebro.</p>

<ul class="actions">
    <a  class="button big" onclick="atualizainf(1)" >Começar</a>
</ul>
