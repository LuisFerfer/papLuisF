


<h2>Memória Verbal</h2>
<p>Irão aparecer palavras durante o jogo, uma de cada vez.</p>
<p>Caso seja uma palavra nova clique NOVO.
    <br>Se já tiver visto essa palavra clique VISTO.</p>

<p>Tem 1 vida, se falhar 1 vez, acaba.</p>
<ul class="actions">
    <a  class="button big" onclick="atualiza(1)" >Começar</a>
</ul>

