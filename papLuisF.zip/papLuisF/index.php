<?php include_once("includes/bodybase.inc.php");
top();


?>

    <script>
        var stage=1;
        $('document').ready(function (){
          swap(stage);
            //alert('aaa');
        });


    </script>


    <!-- Banner -->
    <section id="banner">


    </section>

    <!-- Two -->
    <section id="two" class="wrapper style2 special">
        <div class="container">
            <header class="major">
                <h2>Vermo!</h2>
                <p>Treine o seu cérebro.</p>
            </header>

        </div>

    </section>


<?php bottom(); ?>