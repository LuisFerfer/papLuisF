<h2>Modo Números</h2>
<p>Irão aparecer números durante o jogo, um de cada vez.</p>
<p>O tempo para memorizar vai aumentado a cada número correto.</p>
<p>Quando o tempo terminar, insira o numero na caixa que aparece no ecrã.</p>

<ul class="actions">
    <li>
        <a  class="button big" onclick="atualizanum(1)">Começar</a>
    </li>
</ul>