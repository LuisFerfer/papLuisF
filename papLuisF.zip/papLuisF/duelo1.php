<h2>Modo Duelo</h2>
<p>--------------</p>
<p>--------------</p>
<p>--------------</p>

<ul class="actions">
    <li>
        <a  class="button big" onclick="atualizaduelo(1)">Começar</a>
    </li>
</ul>